/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Utility;

import java.awt.Component;
import java.awt.Container;
import java.util.HashMap;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author wangjie
 */
public class FormComponentMap {

    private final HashMap componentMap;
    private final Container contentPane;

    // Constructor  
    public FormComponentMap(JFrame form) {     
        this.contentPane = form.getContentPane();
        this.componentMap = new HashMap<>();
        createComponentMap(contentPane);
    }

    // recursively parse through all of the child components into the map
    private void createComponentMap(Component c) {
        this.componentMap.put(c.getName(), c); //put parent component into map
        //JOptionPane.showMessageDialog(null, c.getName());

        for (Component child : ((Container) c).getComponents()) {
            createComponentMap(child); // recursive call on every child
        }
    }

    // Look up a component by its name
    public Component getComponentByName(String name) {

        if (componentMap.containsKey(name)) {
            return (Component) componentMap.get(name);
        } else {
            return null;
        }
    }

}
