/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MyDatabase;
import java.sql.Connection; 
import java.sql.SQLException;
/**
 *
 * @author Richard
 */
public interface DBManager {
    public Connection makeConnection() throws SQLException;
    public boolean validateUser(String username, String password);
    public Connection getConn();
    public void setConn(Connection conn) throws SQLException;
    public void setPassword(String password);
    public void setUsername(String username);
    public Object runQuery(String query, int out);//out: 1-return ResultSet;0-return String;
    public String runUpdate(String update);
}
