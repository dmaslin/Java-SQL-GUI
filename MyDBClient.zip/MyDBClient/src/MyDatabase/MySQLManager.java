/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MyDatabase;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Richard
 */
public class MySQLManager implements DBManager {
    private final String driverName = "com.mysql.jdbc.Driver";
    private Connection conn = null;
     private String url = "jdbc:mysql://localhost:3306/testing";
     private String username = "root";
     private String password = "";

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public  String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    public MySQLManager(){
        
    }
 
     public MySQLManager(String url, String username, String password) throws SQLException {
        this.url = url;
         this.username = username;
        this.password = password;
 }

    @Override
    public Connection makeConnection() throws SQLException {
        try {
            Class.forName(this.driverName);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(MySQLManager.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        
        Connection myconn;
        myconn = DriverManager.getConnection(this.url, this.username, this.password);
        
        this.setConn(myconn);
        return this.getConn();
    }

    @Override
    public boolean validateUser(String username, String password) {
        try {
            
            this.makeConnection();
        
        } catch (SQLException ex) {
            Logger.getLogger(MySQLManager.class.getName()).log(Level.SEVERE, null, ex);
        }
       
        Connection myconn = this.getConn();
        PreparedStatement pst = null;
        try {
            pst = myconn.prepareStatement("select * from login where username = ? and password = ?");
        } catch (SQLException ex) {
            Logger.getLogger(MySQLManager.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        try {
            pst.setString(1, username);
            pst.setString(2, password);
            ResultSet rs = pst.executeQuery();
            if(rs.next() ){
                return true;
            }
            else
                return false;
        } catch (SQLException ex) {
            Logger.getLogger(MySQLManager.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "invalid username or password\nlog in denied try again", null, JOptionPane.ERROR_MESSAGE);
            return false;
            
            
        }
        
        
        
        
        
       
    }

    @Override
    public Connection getConn() {
        return this.conn; 
    }

    @Override
    public void setConn(Connection conn) throws SQLException {
       this.conn = conn;
    }

    @Override
    public Object runQuery(String query, int out) {
        // out: 1-return String others-return ResultSet
        
        String result = "";
        String currCol = "";
        ResultSet rs = null;

        try {

            Statement st = this.conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            rs = st.executeQuery(query);//Execute a query and save the results to rs

            if (out != 1) {

                return rs;// Return the query results in a ResultSet

            } else {

                int ncol = rs.getMetaData().getColumnCount();//Get table column size            
                for (int i = 1; i <= ncol; i++) {// Iterate from 1 to table column size
                    result += rs.getMetaData().getColumnName(i) + " ";//Read each table column name
                }

                result += "\n";//Write a new line into the result to be returned in the end of this method           
                while (rs.next()) {// Read each row
                    for (int i = 1; i <= ncol; i++) {
                        currCol = rs.getString(i) + " ";// Read each cell in String in the row and add a space
                        result += currCol; //append the cell into the returned result
                    }
                    result += "\n";
                }

                rs.last();//Move the cursor to the last row.
                int nrow = rs.getRow();  // Get table row size        
                result += "Number of rows in the result set is " + nrow + "\n";// Write row size into result

            }// End IF-ELSE
            
        } catch (SQLException ex) {// Displyas the SQL error if any is cautght        
            JOptionPane.showMessageDialog(null, ex, null, JOptionPane.ERROR_MESSAGE);
            Logger.getLogger(MySQLManager.class.getName()).log(Level.SEVERE, null, ex);
        }

        return result; //return query result in a String

    }
	
	
    @Override
    public String runUpdate(String update) {

        String result = null;
        int updateCount = 0;

        try {

            Statement st = this.conn.createStatement();// Prepare statement            
            updateCount = st.executeUpdate(update);// Execute update
            st.close();
            result = "\n" + updateCount + "rows have been updated.\n";

        } catch (SQLException ex) {// Displays the SQL error if exists
            Logger.getLogger(MySQLManager.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, ex, null, JOptionPane.ERROR_MESSAGE);
        }

        return result;

    }
}
